# -*- make prediction one NN -*-

import numpy as np 
import matplotlib.pyplot as plt

import data_preprocessing_NN as dpp
import user_NNP as user

import keras 

#define the activation function for the NNP
def sigmoid(x):
    return(1/(1+np.exp(-x)))

def relu(x):
    return(np.max([0,x]))

def softplus(x):
    return(np.ln(1+np.exp(x)))


#build the HDNNP
def prediction_NN(predict,N_atoms_file,model_label,N_atoms_model,activation_function,G_parameters=[]):
    
    if activation_function =='tanh': activation_function = np.tanh
    elif activation_function == 'sigmoid': activation_function = sigmoid
    elif activation_function == 'relu': activation_function = relu
    elif activation_function == 'softplus': activation_function = softplus
    
    if type(predict) == str :
        #get data to make the prediction
        predict = dpp.data_preprocess(predict,N_atoms_file,test_data=False,G_parameters=G_parameters)[0];
    
    predict_inputs = predict[0] ; real_outputs = predict[1] ; 
    
    #load the model
    model = keras.models.load_model(model_label)
    
    #get the weights 
    weights = model.get_weights() 
    
    if type(predict_inputs) == list : predict_inputs = np.array(predict_inputs);
    
    predict_outputs = []
    for k in range(0,np.shape(predict_inputs)[1]):
        
        predict_input = predict_inputs[:,k,:]
        prediction_i = [];
        
        for i in range(0,N_atoms_model):

            #get the inputs
            i_input = predict_input[i%N_atoms_file]
            #get the indexes
            
            layer_in = i_input;
            layer_1 = activation_function(np.matmul(layer_in,weights[0])+weights[1]); 
            layer_2 = activation_function(np.matmul(layer_1,weights[2])+weights[3]); 
            layer_out = np.matmul(layer_2,weights[4])+weights[5]; 
            
            prediction_i.append(layer_out)
            
        predict_outputs.append(np.sum(prediction_i))
        
    real_outputs = real_outputs[:,0::N_atoms_file,:][:,0]*(N_atoms_model/N_atoms_file)
    
    plt.figure()
    plt.plot(real_outputs,predict_outputs,'r.',label='NN prediction')
    plt.plot(real_outputs,real_outputs,'b')
    plt.xlabel(r'$y_\mathrm{test}$')
    plt.ylabel(r'$y_\mathrm{predict}$')
    plt.title(r'\texttt{keras\_model}')
    plt.show()
    
# =============================================================================
#     #gradients 
#     #get the quantity to differenciate
#     output = model.output
#     inputs = model.input
#     
#     #get the variable of differentiation
#     variables = model.trainable_weights
#     
#     #import the module backend for BP
#     from keras import backend as k
#     
#     #compute the gradients of output/variables : dE/dG
#     gradients = k.gradients(output,inputs)
#     derivative = k.function([keras_model.input],gradients)
#     
#     dEdG_i = derivative([predict_inputs[0]])
# =============================================================================
    
    return(predict_outputs)




