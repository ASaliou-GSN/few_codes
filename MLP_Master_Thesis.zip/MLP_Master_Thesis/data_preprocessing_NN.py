# -*- Data preprocessing -*-

#import the packages
import numpy as np
import pandas as pd 

import user_NNP as user

import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split #splitting the data
from sklearn.preprocessing import StandardScaler  #regularize the data

#group the data by configuration
def id_configurations(df,N_atoms):
    N_config = int(len(df)/user.N_atoms_simul) ; 
    configurations = [df[i*N_atoms:(i+1)*N_atoms:1] for i in range(0,N_config)]
    return(configurations)

#group the data by atom
def id_atoms(df,N_atoms):
    N_config = int(len(df)/user.N_atoms_simul) ; 
    configurations = [df[i::N_atoms] for i in range(0,N_atoms)]
    return(configurations)

#precondition according to a certain norm
def data_precondition(df_X,N_atoms,X_label=user.X_label,preconditioning='scale',G_parameters=[]):

    #number of configurations in the file : 
    N_config = int(len(df_X)/N_atoms)
    
    #features_dataframe
    G2_label = [label for label in X_label if 'G2' in label]
    G5_label = [label for label in X_label if 'G5' in label]
    
    if G_parameters == [] : 
        dG2 = df_X[G2_label] ; G2_mean = dG2.mean(axis=0) ; G2_std = dG2.std(axis=0) ; G2_max = dG2.max() ; G2_min = dG2.min()
        dG5 = df_X[G5_label] ; G5_mean = dG5.mean(axis=0) ; G5_std = dG5.std(axis=0) ; G5_max = dG5.max() ; G5_min = dG5.min()
        G_parameters = [G2_mean,G2_std,G2_max,G2_min,G5_mean,G5_std,G5_max,G5_min]

    else : 
        dG2 = df_X[G2_label] ; G2_mean = G_parameters[0] ; G2_std = G_parameters[1] ; G2_max = G_parameters[2] ; G2_min = G_parameters[3]
        dG5 = df_X[G5_label] ; G5_mean = G_parameters[4] ; G5_std = G_parameters[5] ; G5_max = G_parameters[6] ; G5_min = G_parameters[7]

    G_parameters = [G2_mean,G2_std,G2_max,G2_min,G5_mean,G5_std,G5_max,G5_min]

    #take every atom
    features_G2_i= np.array([dG2.iloc[i::N_atoms].to_numpy() for i in range(0,N_atoms)])
    features_G5_i= np.array([dG5.iloc[i::N_atoms].to_numpy() for i in range(0,N_atoms)])
     
    #preconditioning the data 
    
    N_features_G2 = len(G2_label) ; N_features_G5 = len(G5_label) ; 
    
    if preconditioning == 'scale' : 
        for f in range(0,N_features_G2): 
            features_G2_i[:,:,f] = 2*(features_G2_i[:,:,f] - G2_min[f])/(G2_max[f]-G2_min[f])-1

        for f in range(0,N_features_G5): 
            features_G5_i[:,:,f] = 2*(features_G5_i[:,:,f] - G5_min[f])/(G5_max[f]-G5_min[f])-1
 
    elif preconditioning == 'shift' : 
        for f in range(0,N_features_G2): 
            features_G2_i[:,:,f] = features_G2_i[:,:,f] - G2_mean[f]

        for f in range(0,N_features_G5): 
            features_G5_i[:,:,f] = features_G5_i[:,:,f] - G5_mean[f]
     
    elif preconditioning == 'scale and shift' : 
        for f in range(0,N_features_G2):
            features_G2_i[:,:,f] = 2*(features_G2_i[:,:,f] - G2_min[f])/(G2_max[f]-G2_min[f])-1
            features_G2_i[:,:,f] = features_G2_i[:,:,f] - features_G2_i[:,:,f].mean(axis=1)
 
        for f in range(0,N_features_G5): 
            features_G5_i[:,:,f] = 2*(features_G5_i[:,:,f] - G5_min[f])/(G5_max[f]-G5_min[f])-1
            features_G5_i[:,:,f] = features_G5_i[:,:,f] - features_G5_i[:,:,f].mean(axis=1)
    
    elif preconditioning == 'stand' : 
        for f in range(0,N_features_G2): 
            features_G2_i[:,:,f] = (features_G2_i[:,:,f] - G2_mean[f])/G2_std[f]

        for f in range(0,N_features_G5): 
            features_G5_i[:,:,f] = (features_G5_i[:,:,f] - G5_mean[f])/G5_std[f]
    
    res = np.append(features_G2_i,features_G5_i,axis=2)
    return(np.einsum('ijk->jik',res),G_parameters)


def data_preprocess(training_file,N_atoms,test_data=True,G_parameters=[]): 

    #read the data
    df = pd.read_csv(training_file,header=0)
    
    #number of configurations in the file : 
    N_config = int(len(df)/N_atoms)
    
    #gather the features for each atom
    configurations = id_configurations(df,N_atoms)
    
    if test_data == True : #otherwise just preprocess the data
        #splitting the sets
        train, test = train_test_split(configurations, test_size=0.2,shuffle = True)
        train = pd.concat(train); test = pd.concat(test)
        
        #inputs and outputs definition
        #inputs and outputs definition
        X_label = user.X_label
        Y_label = user.Y_label
        
        train_X, test_X = train[X_label],test[X_label]
        train_y, test_y = train[Y_label].to_numpy(),test[Y_label].to_numpy()
        
        #preconditionate the input data 
        train_X,G_parameters = data_precondition(train_X,N_atoms,X_label,preconditioning=user.preconditioning)
        test_X = data_precondition(test_X,N_atoms,X_label,preconditioning=user.preconditioning,G_parameters=G_parameters)[0]
        
        train_y = np.array(id_configurations(train_y,N_atoms)) ; test_y = np.array(id_configurations(test_y,N_atoms))
            
        #reshape for every atoms to be trained with the good feature
        train_X = [train_X[:,i,:] for i in range(0,N_atoms)] ; 
        test_X = [test_X[:,i,:] for i in range(0,N_atoms)]
    
        return([train_X,train_y],[test_X,test_y],G_parameters)
    
    else : 

        train = pd.concat(configurations)
        
        #inputs and outputs definition
        #inputs and outputs definition
        X_label = user.X_label
        Y_label = user.Y_label
        
        train_X = train[X_label]
        train_y = train[Y_label].to_numpy()
        
# =============================================================================
#         #regularize the data
#         scaler = StandardScaler()
#         scaler.fit(train_X)
#         
#         train_X = scaler.transform(train_X)
#         
# =============================================================================
        
        #get arrays
        if G_parameters == []:    
            train_X,G_parameters = data_precondition(train_X,N_atoms,X_label=X_label,preconditioning=user.preconditioning)
        else:
            train_X = data_precondition(train_X,N_atoms,X_label=X_label,preconditioning=user.preconditioning,G_parameters=G_parameters)[0]

        train_y = np.array(id_configurations(train_y,N_atoms)) ;
            
        #reshape for every atoms to be trained with the good feature
        train_X = [train_X[:,i,:] for i in range(0,N_atoms)] ; 
        
        return([train_X,train_y],[],G_parameters)
    
# =============================================================================
# #compute the initial weights for the training
# def init_weights(training_file,n_atoms):
#     #dataframe
#     df = pd.read_csv(training_file,header=0)
#     #forces dataframe
#     dforces = df[['fx','fy','fz']]
#     
#     #number of configurations in the file : 
#     n_config = int(len(dforces)/n_atoms)
#     
#     #take the norm
#     dforces2 = np.square(dforces).sum(axis=1)
#     
#     #average over configurations
#     averaged_forces2 = np.array([np.sum(dforces2[i::n_atoms])/n_config for i in range(0,n_atoms)])
#     
#     #compute the weights 
#     weights = 0.2/(0.2*+averaged_forces2)
#     
#     return(weights)
# =============================================================================



        



        
            
            


