# -*- need function for the creation of the input database, behler related -*-

import numpy as np 
import time

#cut-off function 
def f_c(distances,cut_off) : 
    #if type(distances) == np.float64 or type(distances) == float:
    if distances <= cut_off :
        res=0.5*(np.cos(np.pi*distances/cut_off)+1)
    else :
        res=0
    return(res)


#compute behler coordinates with features in the loops
def behler_coordinates(distances,features_G2=None,features_G5=None):
    res = []
    nb_config = 0
    if distances == [] :
        return(res)

    for configuration in distances:

        nb_config = nb_config + 1
        ttb = time.time ()
        N_atoms = len(configuration)
        if features_G2 != None :
             N_G2 = len(features_G2)
             G2 = [ [0 for col1 in range(N_G2)]\
                       for col2 in range(N_atoms)] 
        if features_G5 != None :
             N_G5 = len(features_G5)
             G5_j = [[ [0 for col1 in range(N_G5)]\
                          for col2 in range(N_atoms)] \
                          for col3 in range(N_atoms)] 

        for i in range(0,N_atoms):

            for j in range(i+1,N_atoms): 
                    r_ij=configuration[i][j] 
                    if features_G2 != None :
                        kf = 0
                        for feature in features_G2 : 
                            cut_off = feature[0]; width = feature[1]; shift = feature[2] ;
                            if r_ij <= cut_off : 
                                G2_j = np.exp(-width*(r_ij-shift)**2)*f_c(r_ij,cut_off)
                            else : G2_j = 0
                            G2[i][kf] += G2_j
                            G2[j][kf] += G2_j
                            kf = kf + 1
                    
                    if features_G5 != None :
                        for k in range(j+1,N_atoms):
                            if k!=i:
                                r_ik=configuration[i][k]
                                r_jk=configuration[j][k]
                                cos_theta_jik = (r_jk**2-r_ik**2-r_ij**2)/(2*r_ik*r_ij)
                                r_2 = r_ij**2+r_ik**2
                                #compute G5
                                kf5 = 0
                                for feature in features_G5 : 
                                    cut_off = feature[0] ; width = feature[1] ; 
                                    norm = feature[2] ; inversion = feature[3] ;   
                                    cut=f_c(r_ij,cut_off)*f_c(r_ik,cut_off)
                                    if (r_ij <= cut_off and r_ik <= cut_off) :
                                        angular=2**(1-norm)*(1+inversion*cos_theta_jik)**norm 
                                        radial=np.exp(-width*(r_2))
                                        cut=f_c(r_ij,cut_off)*f_c(r_ik,cut_off)
                                        G5_ij= angular*radial*cut 
                                    else : G5_ij= 0
                                    G5_j[j][i][kf5] += G5_ij
                                    G5_j[i][j][kf5] += G5_ij
                                    kf5 = kf5 + 1
        if features_G5 != None :
            G5 = np.sum(G5_j,axis=1)                     
        if features_G2 == None : 
            res.append(G5)
            print('Calculating Behler G5 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
        elif features_G5 == None : 
            res.append(G2)
            print('Calculating Behler G2 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
        else : 
            res.append(np.append(G2,G5,axis=1))
            print('Calculating Behler G2+G5 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
    return(res)


# compute behler coordinates with features in the loops : old version
def behler_coordinates_old(distances,features_G2=None,features_G5=None):
    res = []
    nb_config = 0
    if distances == [] :
        return(res)
    for configuration in distances:

        nb_config = nb_config + 1
        ttb = time.time ()
        N_atoms = len(configuration)
        G2=[]; G5=[];

        for i in range(0,N_atoms):
            G2_temp = [] ; G5_temp = [] ; 
#            ncountvois = 0;
            for j in range(0,N_atoms): 
                if j!=i: 
#                   print(i, j, configuration[i][j])
                    r_ij=configuration[i][j] 
                    G2_features = [] ;
#                    if r_ij > 3**(1./2.)*6.7030688442967747e+00/2:
#                       print ("warning", r_ij )
                    if features_G2 != None :
                        for feature in features_G2 : 
                            cut_off = feature[0]; width = feature[1]; shift = feature[2] ;
                            if r_ij <= cut_off : 
#                                ncountvois = ncountvois+1
                                G2_j = np.exp(-width*(r_ij-shift)**2)*f_c(r_ij,cut_off)
                            else : G2_j = 0
                            G2_features.append(G2_j)  
                    
                    if features_G5 != None :
                        for k in range(j+1,N_atoms):
                            if k!=i:
                                r_ik=configuration[i][k]
                                r_jk=configuration[j][k]
                                cos_theta_jik = (r_jk**2-r_ik**2-r_ij**2)/(2*r_ik*r_ij)
                                r_2 = r_ij**2+r_ik**2
                                G5_features = []                            
                                #compute G5
                                for feature in features_G5 : 
                                    cut_off = feature[0] ; width = feature[1] ; 
                                    norm = feature[2] ; inversion = feature[3] ;   
                                    cut=f_c(r_ij,cut_off)*f_c(r_ik,cut_off)
                                    if (r_ij <= cut_off and r_ik <= cut_off) :
                                        angular=2**(1-norm)*(1+inversion*cos_theta_jik)**norm 
                                        radial=np.exp(-width*(r_2))
                                        cut=f_c(r_ij,cut_off)*f_c(r_ik,cut_off)
                                        G5_j = angular*radial*cut 
                                    else : G5_j = 0
                                    G5_features.append(G5_j)
                                
                            G5_temp.append(G5_features)                    
                    G2_temp.append(G2_features)          
            G2.append(np.sum(G2_temp,axis=0))                  
            G5.append(np.sum(G5_temp,axis=0))
        if features_G2 == None : 
            res.append(G5)
            print('Calculating Behler G5 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
        elif features_G5 == None : 
            res.append(G2)
            print('Calculating Behler G2 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
        else : 
            res.append(np.append(G2,G5,axis=1))
            print('Calculating Behler G2+G5 Features config ', nb_config, ', ',time.time()-ttb,'sec.',flush = True)
    return(res)

#precondition 
def behler_preconditioning(coordinates,normalisation=None):
    res=[]
    N_atoms = np.shape(coordinates)[1]
    features = np.shape(coordinates)[2]
    for configuration in coordinates:
        feats = []
        for i in range(0,features):
            g = configuration[:,i]
            if normalisation == 'shift' : 
                feats.append(g-1/len(g)*np.sum(g))
            elif normalisation =='scale and shift':
                g = 2*(g - np.min(g))/(np.max(g)-np.min(g))-1
                feats.append(temp-1/len(g)*np.sum(g))
            elif normalisation == 'stand' :
                feats.append(1/np.std(g)*(g-1/len(g)*np.sum(g)))            
            elif normalisation == 'scale' : 
                feats.append(2*(g - np.min(g))/(np.max(g)-np.min(g))-1)
        res.append(feats)
    return(res)



