# -*- fuse the data-*- 

from read_data import fusion_csv

import user_NNP as user

import time


#fusion in the isochore repertories 
training_files = []
for density in user.densities :
        #training_files.append(['D:\\Documents\\SIMAP\\Neural_Network_Potential\\Data_training\\LAMMPS_files\\BDD-LJ-dens'+density[0]+'\\training.d'+density[1]+'.T'+ temperature +'.csv' for temperature in user.temperatures])
        training_files.append(['D:\\Documents\\SIMAP\\Neural_Network_Potential\\Python\\data_froggy\\BDD-LJ-dens'+density[0]+'\\training.d'+density[1]+'.T'+ temperature +'.csv' for temperature in user.temperatures])
fused_labels = []
for density in user.densities:
    fused_labels.append('D:\\Documents\\SIMAP\\Neural_Network_Potential\\Data_training\\LAMMPS_files\\BDD-LJ-dens'+density[0]+'\\training.d'+density[1]+'.csv')

for i in range(0,len(user.densities)):
    
    fusion_csv(training_files[i],fused_labels[i])
    
    print('The files have been fused on the isochore')
    
#and then fusion over all repertories 
fusion_csv(fused_labels,'full_G2G532_120.csv')
