#contains the function need to build the NN 

# -*- create the model -*-

"""making the test reproducible""" 
seed_value=3

# 1. Set the `PYTHONHASHSEED` environment variable at a fixed value
import os
os.environ['PYTHONHASHSEED']=str(seed_value)

# 2. Set the `python` built-in pseudo-random generator at a fixed value
import random as rn
rn.seed(seed_value)

# 3. Set the `numpy` pseudo-random generator at a fixed value
import numpy as np
np.random.seed(seed_value)

# 4. Set the `tensorflow` backend
import tensorflow as tf 
tf.random.set_seed(seed_value)

from keras import regularizers
from keras import optimizers

from os import path 

import user_NNP_h30h30h30 as user

#generate the NN network
def generate_model(N_atoms,N_features,model_label,weights=[]):
    
    if path.isfile(model_label) :
        print('This model already exists in the current path, please erase it to rewrite a new one.')
        return()
    
    #NN parameters
    batch_size = user.batch_size ; shuffle = user.shuffle
    alpha_l2 = user.alpha_l2 #l2 norm regularization 
    hidden_layer_sizes = user.hidden_layer_sizes #NN hidden layers 
    max_epochs = user.max_epochs #maximum number of epochs algorithms should train if no early_stopping
    activation_function = user.activation_function #layers' activation function
    min_delta = user.min_delta ; patience = user.patience #early_stopping parameters
    
    #size of the output
    output_size = len(user.Y_label)
    
    #optimizer
    optimizer_adam = optimizers.Adam(learning_rate=0.001, beta_1=0.9,\
                                              beta_2=0.999, epsilon=1e-08, amsgrad=False)     
    # --- Keras --- #
    
    from keras.layers.merge import add
    from keras.models import Model
    from keras.layers import Dense, Input
    
    sub_networks=[] ; sub_networks_in=[] ; sub_networks_out=[]
    
    if len(hidden_layer_sizes) == 2 : 
    
        layer_h1 = Dense(hidden_layer_sizes[0],input_dim = (N_features,),activation = activation_function,name='atom_h1')
        layer_h2 = Dense(hidden_layer_sizes[1],input_dim = (N_features,hidden_layer_sizes[0]),activation = activation_function,name='atom_h2')
        layer_out = Dense(output_size)
    
    elif len(hidden_layer_sizes) == 3 : 
    
        layer_h1 = Dense(hidden_layer_sizes[0],input_dim = (N_features,),activation = activation_function,name='atom_h1')
        layer_h2 = Dense(hidden_layer_sizes[1],input_dim = (N_features,hidden_layer_sizes[0]),activation = activation_function,name='atom_h2')
        layer_h3 = Dense(hidden_layer_sizes[2],input_dim = (hidden_layer_sizes[0],hidden_layer_sizes[1]),activation = activation_function,name='atom_h3')
        layer_out = Dense(output_size)
    
    else :
        
        layer_h1 = Dense(hidden_layer_sizes[0],input_dim = (N_features,),activation = activation_function,name='atom_h1')
        layer_out = Dense(output_size)
        
    for i in range(0,N_atoms) : 
        
        if weights != [] :
        
            #weights and biases
            w_h1 = weights[i]*np.ones((N_features,hidden_layer_sizes[0])) ; b_h1 = np.zeros((hidden_layer_sizes[0],))
            w_h2 = weights[i]*np.ones((hidden_layer_sizes[0],hidden_layer_sizes[1])) ; b_h2 = np.zeros((hidden_layer_sizes[1],))
            w_output = weights[i]*np.ones((hidden_layer_sizes[1],1)) ; b_output = np.zeros((1,))
        
            #writting the weights in the good format
            weights_h1 = [w_h1,b_h1]
            weights_h2 = [w_h2,b_h2]
            weights_output = [w_output,b_output]
            
            #creating the layers
            subnet_in = Input(shape=(N_features,))
            subnet_h1 = layer_h1(subnet_in)#subnet_h1 = Dense(hidden_layer_sizes[0],input_dim = (N_features,),activation = activation_function,name='atom'+str(i)+'h1')(subnet_in)
            subnet_h2 = layer_h2(subnet_h1)#subnet_h2 = Dense(hidden_layer_sizes[1],input_dim = (N_features,hidden_layer_sizes[0]),activation = activation_function,name='atom'+str(i)+'h2')(subnet_h1)
            subnet_out = layer_out(subnet_h2)
    
            #building the model
            subnet = Model(subnet_in,subnet_out,name='atom'+str(i))
            
            sub_networks_in.append(subnet_in)
            sub_networks_out.append(subnet_out)
            sub_networks.append(subnet)
            
                    
        else : 
            
            if len(hidden_layer_sizes) == 2 : 
            
                #creating the layers
                subnet_in = Input(shape=(N_features,))
                subnet_h1 = layer_h1(subnet_in)#subnet_h1 = Dense(hidden_layer_sizes[0],input_dim = (N_features,),activation = activation_function,name='atom'+str(i)+'h1')(subnet_in)
                subnet_h2 = layer_h2(subnet_h1)#subnet_h2 = Dense(hidden_layer_sizes[1],input_dim = (N_features,hidden_layer_sizes[0]),activation = activation_function,name='atom'+str(i)+'h2')(subnet_h1)
                subnet_out = layer_out(subnet_h2)
                
            
                #building the model
                subnet = Model(subnet_in,subnet_out,name='atom'+str(i))
                
                sub_networks_in.append(subnet_in)
                sub_networks_out.append(subnet_out)
                sub_networks.append(subnet)
                
            elif len(hidden_layer_sizes) == 3 : 
            
                #creating the layers
                subnet_in = Input(shape=(N_features,))
                subnet_h1 = layer_h1(subnet_in)
                subnet_h2 = layer_h2(subnet_h1)
                subnet_h3 = layer_h3(subnet_h2)
                subnet_out = layer_out(subnet_h3)
                
            
                #building the model
                subnet = Model(subnet_in,subnet_out,name='atom'+str(i))
                
                sub_networks_in.append(subnet_in)
                sub_networks_out.append(subnet_out)
                sub_networks.append(subnet)
            
            else :
                
                #creating the layers
                subnet_in = Input(shape=(N_features,))
                subnet_h1 = layer_h1(subnet_in)
                subnet_out = layer_out(subnet_h1)
                
            
                #building the model
                subnet = Model(subnet_in,subnet_out,name='atom'+str(i))
                
                sub_networks_in.append(subnet_in)
                sub_networks_out.append(subnet_out)
                sub_networks.append(subnet)

    
    out = add(sub_networks_out)
    #out = Dense(1,name='output')(concatenated)
    
    merged_model = Model(sub_networks_in,out)
    merged_model.compile(optimizer=optimizer_adam,loss='mean_squared_error')
    
    #save the model
    merged_model.save(model_label)

    return()

#show the graph of the model
"""
import keras ; import pydot ; import pydotplus;  import graphviz
keras.utils.plot_model(keras.models.load_model(model_label), "HDNN.png", show_shapes=True)
"""

# -*- train the NN -*-

import keras 
from tensorflow.keras.callbacks import EarlyStopping

from data_preprocessing_NN import data_preprocess

import matplotlib.pyplot as plt

import time

#train the model with either a file or a database that will be preprocessed
def train_model(model_label,train,N_atoms,test=()):
    
    #load the model
    model = keras.models.load_model(model_label)
    
    if type(train) == str :
        train = data_preprocess(train,N_atoms,test_data=False)[0]
    
    #separate inputs and outputs
    train_X = train[0] ; train_y = train[1]
    
    #earlystopping
    callbacks = [EarlyStopping(monitor='val_loss', min_delta=user.min_delta,patience=user.patience, mode='min',restore_best_weights=True)]
    
    t_0 = time.time()
    
    #fit the model
    if test == () : 
        fit = model.fit(train_X,train_y,validation_split=0.2,batch_size=user.batch_size,\
                      shuffle=user.shuffle, epochs=user.max_epochs,verbose=2,callbacks=callbacks)   
    else:
        fit = model.fit(train_X,train_y,validation_data=test,batch_size=user.batch_size,\
                              shuffle=False, epochs=user.max_epochs,verbose=2,callbacks=callbacks)   
    
    print( "Number of epochs: ", len(fit.history['loss']))
    print( "Loss: ", fit.history['loss'][-1])
    print( "Val loss: ", fit.history['val_loss'][-1])
    print("Execution time:",time.time()-t_0,"s")
        
    #save the trained model
    model.save(model_label)
    
    plt.figure()
    plt.plot(fit.history['loss'],label=r'loss')
    plt.plot(fit.history['val_loss'],label=r'val_loss')
    plt.xlabel(r'epoch')
    plt.ylabel(r'loss')
    plt.legend()
    plt.title(r'loss evolution of the trained NN')
    plt.show()
    
    return(fit)

# -*- predict with the NN -*-
import numpy as np

def predict_model(model_label,test,N_atoms):

    #load the model
    model = keras.models.load_model(model_label)

    if type(test) == str :
        test = data_preprocess(test,N_atoms,test_data=False)[0]
    
    #separate inputs and outputs
    test_X = test[0] ; test_y = test[1]

    #get the predictions
    predict_y = model(test_X)
    test_y = test_y[:,0::N_atoms,:][:,0]
    
    #see the convergence of the model
    plt.figure()
    plt.plot(test_y,predict_y,'r.', test_y, test_y, 'b')
    plt.xlabel(r'$y_\mathrm{test}$')
    plt.ylabel(r'$y_\mathrm{predict}$')
    plt.title(r'\texttt{keras\_model}')
    plt.show()
    
    return(predict_y)





