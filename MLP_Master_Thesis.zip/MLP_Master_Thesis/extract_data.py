# -*- function that extract data from the file -*-

import read_data as read
import user_in as user 

import numpy as np 
import pandas as pd 

from os import path
import time

def compute_csv(thefile,N_config,i_shift,i_start,outputs,behler_file,training_file,production_file=None) :
    
    # -*- READ THE DATA -*-             
    
    #first we read the data into dataframes
    print('Selected ', str(N_config), ' configurations from file')
    print('Pre-sampling : taking each ',i_shift, ' configurations from selected')
    print('Starting from configuration ',i_start, ' from selected')
    print('Reading ', int((N_config-i_start)/i_shift), ' configurations')
    tt0 = time.time() 
    if 'dump' in thefile : 
        data = read.dump_to_list(thefile, N_config, i_shift, i_start)
        production = pd.read_csv(production_file,header=0,delim_whitespace=True)
    elif 'OUTCAR' in thefile : 
        data = read.outcar_to_list(thefile, N_config, i_shift, i_start)
    print(' ') 
    print('Done! (',time.time()-tt0,'sec.)') 
    # -*- GET PARAMETERS -*-    
    
    #read the number of atoms
    N_atoms = np.shape(data)[1] ; 
    print('Number of atoms : ', N_atoms)

    #compute the sampling parameters 
    alpha = 3*read.force_mean(data[0]) #sampling threshold=3*F^2_mean of the last config
    max_delay = user.Max_delay 
    
    # -*- SAMPLING -*-
    #sample the data
    if max_delay != 0:
       print('Sampling the data, max delay ',str(max_delay))
       data,sampled_timestep = read.sampling(data,alpha,index=0,max_delay=max_delay) ; #sampling on the forces of a given atom
       N_config = len(data)
       print('Sampling done : ', str(N_config), ' configurations retained')


    # -*- EXTRACT THE DATA REGARDING THE EXPECTED OUTPUTS -*-

    #Now we get the positions, forces, stresses and energies from the files
    #then, we get them into pd.DataFrame
    if max_delay != 0:
        print('Getting positions of sampled data ')
    else:
        print('Getting positions ')

    #Positions
    positions = read.get_positions(data)
    print('') 
    print('Done!') 
    tt0 = time.time() 
    print('Determining distances matrixes ')
    distances = read.get_all_distances(data,mic=True)
    print('Done! (',time.time()-tt0,'sec.)') 
     
    #Forces 
    if 'forces' in outputs :
        forces = read.get_forces(data)
#       print(forces)
        forces = pd.DataFrame(np.array(forces).reshape(N_atoms*N_config,3),columns=['Fx','Fy','Fz'])

    print('Get energies, forces and stresses of sampled data')
    tt0 = time.time() 

    #Stresses 
    if 'stresses' in outputs :
        
        if 'OUTCAR' in thefile : 
            if not path.isfile('stresses.txt') :
                read.write_stress_outcar(thefile)
            stresses_data = [read.get_stress_outcar('stresses.txt')[i] for i in sampled_timestep]
            stresses = []
            for configuration in stresses_data : 
                stress_X = pd.DataFrame([configuration]*N_atoms,columns=['Pxx','Pyy','Pzz','Pxy','Pxz','Pyz'])
                stresses.append(stress_X)
            stress = pd.concat(stresses,axis=0,ignore_index=True)
            print(stress)        
        elif 'dump' in thefile : 
            stress_labels = ['Pxx','Pyy','Pzz','Pxy','Pxz','Pyz'] ; stress = []
            sampled_timestep = np.array(sampled_timestep) #production and dump must have same timesteps
            for label in stress_labels:
                stress_X = production[label].iloc[sampled_timestep] 
                stress.append((stress_X.repeat(N_atoms)).reset_index(drop=True))
            stress = pd.concat(stress,axis=1)
    
    #Energy
    if 'energy' in outputs :
        
        if 'OUTCAR' in thefile : 
            energy = read.get_energy(data)
            energy = (pd.Series(energy,name='E').repeat(N_atoms)).reset_index(drop=True)
        if 'dump' in thefile : 
            energy = production['PotEng'].iloc[sampled_timestep]*N_atoms #in the good format
            energy = (energy.repeat(N_atoms)).reset_index(drop=True)
            energy = energy.rename('E')
            
    print('Done! (',time.time()-tt0,'sec.)') 

    # -*- COMPUTE THE BEHLER COORDINATES -*-
    
    #N_coord is the number of features; 
    #the headers refers to the column names in the output files ;
    #then the coordinates are computed
    
    tt0 = time.time() 
    
    if ('features_G2' in outputs or 'features_G5' in outputs):
        import behler_functions as bl  
    
    if ('features_G2' in outputs and 'features_G5' not in outputs) :     

        N_coord = len(user.features_G2_)
        
        belher_headers = ['G2(feature'+str(i)+')' for i in range(1,N_coord+1)]
            
        behler_coords = bl.behler_coordinates(distances,features_G2=user.features_G2_)

        
    elif ('features_G5' in outputs and 'features_G2' not in outputs) : 
        
        N_coord = len(user.features_G5_) 
        
        belher_headers = ['G5(feature'+str(i)+')' for i in range(1,N_coord+1)]
            
        behler_coords = bl.behler_coordinates(distances,features_G5=user.features_G5_)
    
    elif ('features_G2' in outputs and 'features_G5' in outputs):
        
        N_coord = len(user.features_G2_)+len(user.features_G5_) 
        
        belher_headers = ['G2(feature'+str(i)+')' for i in range(1,len(user.features_G2_)+1)] + ['G5(feature'+str(i)+')' for i in range(1,len(user.features_G5_)+1)]
            
        behler_coords = bl.behler_coordinates(distances,features_G2=user.features_G2_,features_G5=user.features_G5_)

    print('Done! (',time.time()-tt0,'sec.)') 

    if ('features_G2' in outputs or 'features_G5' in outputs):        

        #set the data in the good shape
        behler_csv = np.reshape(behler_coords,(N_atoms*N_config,N_coord))   
    
        #create a DataFrame 
        behler_csv = pd.DataFrame(behler_csv,columns=belher_headers)
        #generate the csv file
        behler_csv.to_csv(behler_file,index=False)
    
    # -*- DATA : ASSEMBLEE ! 
    print('Save the training files : ')
    dataframes =[]
    if 'features_G2' in outputs or 'features_G5' in outputs : 
        dataframes.append(behler_csv)
    
    if 'energy' in outputs : 
        dataframes.append(energy)
    
    if 'forces' in outputs :
        dataframes.append(forces)
    
    if 'stresses' in outputs :
        dataframes.append(stress)

    #put everything together!
    data_csv = pd.concat(dataframes,axis=1)

    #write the file
    data_csv.to_csv(training_file,index=False)
    print('The files have been generated successfully!')
    
    return(dataframes)

    

        
    

    

