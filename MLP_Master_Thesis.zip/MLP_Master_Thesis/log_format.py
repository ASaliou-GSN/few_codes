# -*- test log format

log_file = 'log.d0.8.T0.001.file'
production_file = 'production.d0.8.T0.001.file'

def log_format(log_file,production_file):

    with open(log_file,'r') as file: 
        lines = file.readlines()[0:1023]
    
    with open(production_file,'w') as file:
        for line in lines : 
            if line != '\n':
                first_element = line.split()[0]
                
                if first_element == 'Step': 
                    file.write(line)
                    
                if first_element.isnumeric():
                    if int(first_element)%100 == 0:
                        file.write(line)
                
    return()
            
