# code to bot Lili's Data
# A request ? Take a shot !
if not 'numpy' in globals() or 'pandas' in globals():    
    import pandas as pd ; import numpy as np ; 
    from tabulate import tabulate
    from scipy.stats import ttest_ind, wilcoxon, shapiro,ttest_rel
    import warnings
#%%
def patients_data():
    #list of available data
    names = ['sex','age','origin','side','acuity_logmar','trou_sten','refra_sph',\
         'cyl','ax','spher_eq','pio','implant','iol','target_barret','LA','color',\
         'fibers','WTW','trepanation','keratotomie','KT',\
         'oct','aphake','trauma','trauma_cause','congen',\
         't_pre_chir','elev_pio','hypotonising','glaucome',\
         'trab','valve_ahmed','hypotony','omc','mer','dr','uveitis',\
         'pco','oedema','repos','diplopy','vaulting','evisc',\
         'microspec','ACA','ACA_ctrl','d_corn_cris','d_corn_cris_ctrl','rnfl_op','rnfl_ctrl']
    
    #read the data
    patients = [pd.read_excel('lili.xlsx',skiprows=0,nrows=50,index_col=0)]+\
    [pd.read_excel('lili.xlsx',skiprows=52+52*i,nrows=50,index_col=0) for i in range(16)]

    #format the data from the table
    for p,patient in enumerate(patients) : 
        patient.index=names ; 
        patients[p] = pd.DataFrame([dat[1].replace('oui',True).replace('non',False) for dat in patient.iterrows()]).copy()
        patients[p]=patients[p].iloc[:,0:8]
    return(patients)

#read only if needed, can be long to open
if ('patients' not in globals()) : patients=patients_data() 

#%% first compute mean and stds of a given quantity
#qty='acuity_logmar';times=list(QTYs.columns)
def mean_qty(qty,time,selection,selection_criteria):
    """Study data means and stds"""
     
    #extract the data
    QTYs = [pd.to_numeric(patient.loc[qty],errors='coerce')[0:6] for patient in patients]
            #if (float(patient.loc['keratotomie']['Préop'])==5.5) or float(patient.loc['keratotomie']['Préop']==6)]
            #if (float(patient.loc['keratotomie']['Préop'])==6)]
    QTYs = pd.DataFrame(QTYs).astype(float); n_patients = len(QTYs) ; #print(QTYs)
    
    #get the latest
    last =np.empty(len(QTYs)); last[:]=np.nan
    for i in range(len(QTYs)) : 
        if list(QTYs.iloc[i][0:6].dropna()) != []: last[i]=QTYs.iloc[i][0:6].dropna()[-1].copy()
    QTYs['last']=last ; #print(QTYs)

    
    #do the selection w.r.t. the criterium if required (min or max value)
    if selection:
        
        print(f"\nThe lists of values are:")
        print(tabulate([[f"{qty} {time}"]+list(QTYs[time].fillna(u"\u2205"))]+
                       [[f"{qty} >= {selection_criteria} {time}"]+list(QTYs[QTYs>=selection_criteria][time].fillna(u"\u2205"))],
                       headers=[f"P{i}" for i in range(1,18)],floatfmt=('.1f',)*18))
        print("")
        
        #selection_criteria=0.1 ; #print('Selection criteria only applied to first and final3')
        QTYs=QTYs[QTYs>=selection_criteria]
    else : 
        print(f"\nThe list of values is:")
        print(tabulate(['Total']+[list(QTYs[time].fillna(u"\u2205"))],headers=[f"P{i}" for i in range(1,18)]))
        print("")

    #get the means and stds ; 
    means = QTYs.mean(axis=0); stds = QTYs.std(axis=0)
 
    if selection : print(f"\n ** {qty} taken >= {selection_criteria} at {time} **\n")
    else :  print(f"\n ** {qty} taken without criterium at {time} **")
    
    #########
    #possibility to print selected values to check if the criterium was well applied
    #print(f"\nThe list of the selected values are:")
    #print(tabulate([list(QTYs[time].fillna(u"\u2205"))],headers=[f"P{i}" for i in range(1,18)]))
        #print("; ".join(list(QTYs[time].fillna(u"\u2205").astype(str))),"\n")
    #print("")

    print(f"-> Mean {time} = {np.round(means.loc[time],3)} with std  = {np.round(stds.loc[time],3)}")
    print(f"-> with {round(len(QTYs[time][~QTYs[time].isna()])/n_patients*100,2)}% of the patients for the {time}")
    print(f"-> within a range {QTYs[time][~QTYs[time].isna()].min()} to {QTYs[time][~QTYs[time].isna()].max()}\n")
    #print(QTYs[time]) to check
    
    print('=========================================')
    print("0.3c/min, prix d'un appel local en France")
    print("Non ça va, un bisou ça régale")
    print('=========================================\n')
    return()

#%%
#run the above function with regard to user's input
def run_mean_qty():
    
    print('\n=========================================')
    print('Hi ! This is Choupstat calculator !')
    print('=========================================')

    #user enters quantity and criterium if needed
    qty=input('What quantity do you want ? \n (acuity_logmar,pio,refra_sph,spher_eq,rnfl_op,rnfl_ctrl)\n')
    selection=input('Do you want to do a criterium selection on a value ? (yes/no)\n')
    #! lower to be case independant
    if selection.lower()=='yes' : selection=True 
    else: selection=False
    #choice of selection criterium
    if selection == True : selection_criteria=float(input('What value for the criterium ? \n'))
    else : selection_criteria = None
    #choice of the stage of the study
    time = input("at what time ? (Préop, J8, M1, M2, M3, Final, last)\n")
    
    #run the calculation
    mean_qty(qty,time,selection,selection_criteria)
    return()

#%%
# study the distribution of quantities w.r.t. any other
# it checks weither a quantity is significantly related to another 
# either from the quantity itself of its evolution in time
def distri_qty(qty,cross_comparison,*args):
    """Study data distributions via a Shapiro stat. test"""

    #cross_comparison ask if two different quantities are compared
    #if not, we compare pre vs post surgery
    if not cross_comparison :     
        
        #extract the data
        QTYs = [pd.to_numeric(patient.loc[qty],errors='coerce')[0:6] for patient in patients]
                #if (float(patient.loc['keratotomie']['Préop'])==5.5) or float(patient.loc['keratotomie']['Préop']==6)]
                #if (float(patient.loc['keratotomie']['Préop'])==6)]
        QTYs = pd.DataFrame(QTYs); n_patients = len(QTYs) ; #print(QTYs)
        
        #get the latest value, not all measurements are at M6
        last =np.empty(len(QTYs)); last[:]=np.nan
        for i in range(len(QTYs)) : 
            if list(QTYs.iloc[i][0:6].dropna()) != []: last[i]=QTYs.iloc[i][0:6].dropna()[-1].copy()
        QTYs['last']=last ; 
            
        print(f"Statistics over {len(QTYs)} patients\n")
        
        #show the used values, useful to check too
        print(f"\nThe list of the values are:")
        print(tabulate([['Préop']+list(QTYs['Préop'].fillna(u"\u2205"))]+
                       [['last']+list(QTYs['last'].fillna(u"\u2205"))],
                       headers=[f"P{i}" for i in range(1,18)]))
        print("")
        
        #are data normally distributed ? thanks to Shapiro test

        with warnings.catch_warnings(record=True) as w:
            #print values of shapiro distribution tests
            print(f"{qty} préop: SHAPIRO p-value={round(shapiro(QTYs['Préop'])[-1],4)}")
            print(f"{qty} last: SHAPIRO p-value={round(shapiro(QTYs['last'])[-1],4)}\n")
               
            #normal if p>0.05 ; assuming both need to be normal to assume normality
            #if normality -> Wilcoxon test to study relative significance
            if max(shapiro(QTYs['Préop'])[1],shapiro(QTYs['last'])[1])<0.05 : 
                print(f"Non-normal -> applying Wilcoxon")
                print(f"Préop vs postop: p-value={round(wilcoxon(QTYs['Préop'],QTYs['last'],method='approx')[-1],4)}")
                print(f"Préop vs Max qty: p-value={round(wilcoxon(QTYs['Préop'],QTYs.max(axis=1),method='approx')[-1],4)}\n")
            #else -> Student test
            else : 
                print(f"Normal -> applying Student")
                print(f"Préop vs postop: p-value={round(ttest_rel(QTYs['Préop'],QTYs['last'])[-1],4)}")
                print(f"With a confidence interval : {ttest_rel(QTYs['Préop'],QTYs['last']).confidence_interval()}")
                print(f"Préop vs Max qty:p-value={round(ttest_rel(QTYs['Préop'],QTYs.max(axis=1))[-1],4)}\n")
                print(f"With a confidence interval : {ttest_rel(QTYs['Préop'],QTYs.max(axis=1)).confidence_interval()}")
        #if a warning is brought, good to keep in mind that we only have few values
        if w : print('! Careful, statistic is poor \U0001F92D !')

    #loop if cross_comp
    else :
        #error if wrong input in cross_comparison: 2 quantities required
        if len(qty) != 2 : print('2 quantites are needed for comparison');return()
        
        #extract the data
        QTYs = [[pd.to_numeric(patient.loc[q],errors='coerce')[0:6] for patient in patients] for q in qty]
                #if (float(patient.loc['keratotomie']['Préop'])==5.5) or float(patient.loc['keratotomie']['Préop']==6)]
                #if (float(patient.loc['keratotomie']['Préop'])==6)]
        QTYs = [pd.DataFrame(QTY) for QTY in QTYs]; n_patients = len(QTYs[0]) ; #print(QTYs)
                
        #get the latest
        #here QTYs has two dimensions, for two quantities
        for QTY in QTYs: 
            last =np.empty(len(QTY)); last[:]=np.nan
            for i in range(len(QTY)) : 
                if list(QTY.iloc[i][0:6].dropna()) != []: last[i]=QTY.iloc[i][0:6].dropna()[-1].copy()
            QTY['last']=last ; 
            
        print(f"Statistics over {len(QTYs[0])} patients\n")
        
        #latest values of the quantities are compared
        print(f"\nThe list of the values are:")
        print(tabulate(#[[f"Préop {qty[0]}"]+list(QTYs[0]['Préop'].fillna(u"\u2205"))]+
                       #[[f"Préop {qty[1]}"]+list(QTYs[1]['Préop'].fillna(u"\u2205"))]+
                       [[f"last {qty[0]}"]+list(QTYs[0]['last'].fillna(u"\u2205"))]+
                       [[f"last {qty[1]}"]+list(QTYs[1]['last'].fillna(u"\u2205"))],
                       headers=[f"P{i}" for i in range(1,18)]))
        print("")
        
        #last cleaning in case of 
        for i in range(len(QTYs)) : QTYs[i] = QTYs[i][~(QTYs[i]['last'].isna())]
        
        with warnings.catch_warnings(record=True) as w:
            #print values of shapiro distribution tests
            print(f"{qty[0]} last: SHAPIRO p-value={round(shapiro(QTYs[0]['last'])[-1],4)}")
            print(f"{qty[1]} last: SHAPIRO p-value={round(shapiro(QTYs[1]['last'])[-1],4)}\n")
            
            #normal if p>0.05 ; assuming both need to be normal to assume normality
            #if normality -> Wilcoxon test to study relative significance
            if max(#shapiro(QTYs[0]['Préop'])[1],shapiro(QTYs[1]['Préop'])[1],
                   shapiro(QTYs[0]['last'])[1],shapiro(QTYs[1]['last'])[1])<0.05 : 
                print(f"Non-normal -> applying Wilcoxon")
                #print(f"{qty[0]} vs {qty[1]} préop: p-value={round(wilcoxon(QTYs[0]['Préop'],QTYs[1]['Préop'],method='approx')[-1],4)}")
                print(f"{qty[0]} vs {qty[1]} last: p-value={round(wilcoxon(QTYs[0]['last'],QTYs[1]['last'],method='approx')[-1],4)}\n")
            #else -> Student test
            else : 
                print(f"Normal -> applying Student")
                #print(f"Préop vs postop: p-value={round(ttest_ind(QTYs[0]['Préop'],QTYs[1]['Préop'])[-1],4)}")
                print(f"{qty[0]} vs {qty[1]}: p-value={round(ttest_ind(QTYs[0]['last'],QTYs[1]['last'])[-1],4)}\n")
        
        #if a warning is brought, good to keep in mind that we only have few values
        if w : print('! Careful, statistic is poor \U0001F92D !')

    print('=========================================')
    print("Merci d'avoir utilisé nos services et à bientôt !")
    print("\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600"+
          "\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600\U0001f600")
    print('=========================================\n')
    return()

#%%
#run the previous function w.r.t. the user's inputs
def run_distri_qty():
    
    print('\n=========================================')
    print('Hi ! This is DistribChoup calculator !')
    print('=========================================\n')

    #ask if cross_comp 
    cross_comparison=input("Do you want to cross-compare quantities ? (yes/no)\n")
    
    #choice of the quantities among the availables ones
    if cross_comparison.lower()=='yes' : 
        cross_comparison=True 
        qty=tuple(input('What quantity (2: "q1,q2") do you need ? \n (acuity_logmar,pio,refra_sph,spher_eq,rnfl_op,rnfl_ctrl)\n').split(','))
    
    #OR choice of the single quantity among the availables ones    
    else: 
        cross_comparison=False
        qty=input('What quantities do you need ? \n (acuity_logmar,pio,refra_sph,spher_eq,rnfl_op,rnfl_ctrl)\n')    
    
    #run the function
    distri_qty(qty,cross_comparison)
    return()

