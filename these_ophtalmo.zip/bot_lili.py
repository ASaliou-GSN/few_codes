#code to run to get stats 
if 'fct' not in dir() : import bot_lili_fct as fct

#%%
fct.run_mean_qty()

#%%
fct.run_distri_qty()



