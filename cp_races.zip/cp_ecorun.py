#code to compare races with relative elevation 
#ideal for same races : allow to see where the weaknesses/strengths were
import numpy as np ; import pandas as pd 
import geopy.distance ; from gpxcsv import gpxtolist

import matplotlib as mpl
import matplotlib.pyplot as plt
font = {'family' : 'sans-serif', 'sans-serif' : 'Arial'  ,'size'   : 22}; mpl.rc('font', **font)
mpl.rcParams['xtick.major.size'] = 10 ; mpl.rcParams['xtick.major.width'] = 2;
mpl.rcParams['xtick.minor.size'] = 5 ; mpl.rcParams['xtick.minor.width'] = 1
mpl.rcParams['ytick.major.size'] = 10 ; mpl.rcParams['ytick.major.width'] = 2;
mpl.rcParams['ytick.minor.size'] = 5 ; mpl.rcParams['ytick.minor.width'] = 1
from matplotlib.ticker import (AutoMinorLocator);


#function to plot the gpx files with a background as a quantity "qty"
def plot_pace_gpx(file,color,qty='ele'):
    
    #get gpx data as a csv
    gpx_list = gpxtolist(file)
    
    #into a dataframe
    df = pd.DataFrame(gpx_list)
    
    #format the datetime and compute time intervals between every gpx sample
    datetime = pd.to_datetime(df['time'])
    dt = [(datetime.iloc[i+1]-datetime.iloc[i]).total_seconds() for i in range(len(datetime)-1)]
    
    #compute effective distances from lat/lon values
    dist = [geopy.distance.geodesic(tuple(df[['lat','lon']].iloc[i]),tuple(df[['lat','lon']].iloc[i+1])).m for i in range(len(df)-1)]

    #from distance and time variations compute the pace and set in km/h
    pace = np.array(dist)/np.array(dt) ; #print(pace)
    pace = 1e-3*pace*3600
    
    #x2 for cadence, only one feet data provided
    if qty == 'cad':
        ax_elev.plot(np.cumsum(dist)*1e-3,df[qty][1:]*2,color='k');
        ax_elev.fill_between(np.cumsum(dist)*1e-3,df[qty][1:]*2,color=color,alpha=0.3)
    else : 
        ax_elev.plot(np.cumsum(dist)*1e-3,df[qty][1:],color='k');
        ax_elev.fill_between(np.cumsum(dist)*1e-3,df[qty][1:],color=color,alpha=0.3)
    #adapt scales depending on the parameter
    if qty == 'elev' : ax_elev.set_ylim(df[qty].min()-df[qty].min()*0.1,df[qty].max()+df[qty].max()*0.1)
    elif qty == 'hr' : ax_elev.set_ylim(120,200)
    elif qty == 'cad' : ax_elev.set_ylim(150,200)
    
    ############
    #possibility to check for gap pace
    #gap_pace = [plot_pace[i]*(1+np.diff(df['ele'])[i]/dist[i]*100*(0.05)) if np.diff(df['ele'])[i]>=0 else plot_pace[i]*(1+np.diff(df['ele'])[i]/dist[i]*100*(0.05)) for i in range(len(df)-1)]
    
    #apply a rolling mean to smooth data
    ax.plot(np.cumsum(dist)*1e-3,pd.Series(pace).rolling(5).mean(),color=color)
    return()    

#init figure and twin ax for the background
if 'ax' not in globals() : fig,ax = plt.subplots();ax_elev=ax.twinx()

#plot the two races
plot_pace_gpx('ecorun_2022.gpx',color='b')
plot_pace_gpx('ecorun_2023.gpx',color='r')


#beautifullllllll plot
ax.legend(['2022','2023'],frameon=False)
ax.set_xlabel('Distance(km)')
ax.set_ylabel('Speed(km/h)')
ax_elev.set_ylabel('Elevation(m)',rotation=270,labelpad=20)
for axis in ['top','bottom','left','right']:
    ax.spines[axis].set_linewidth(2)

ax.xaxis.set_minor_locator(AutoMinorLocator()); ax.locator_params(axis='x', nbins=9); 
ax.yaxis.set_minor_locator(AutoMinorLocator()); ax.locator_params(axis='y', nbins=9); 
