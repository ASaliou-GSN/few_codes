# compute the number of hydrogen bonds between two grains in solution
import pandas as pd ; import numpy as np ; import re
import os ; from scipy.spatial.distance import cdist,pdist

#%%
#graphical set up
import matplotlib as mpl
import matplotlib.pyplot as plt ;
font = {'family' : 'sans-serif', 'sans-serif' : 'Arial'  ,'size'   : 22}; mpl.rc('font', **font)
mpl.rcParams['xtick.major.size'] = 10 ; mpl.rcParams['xtick.major.width'] = 2;
mpl.rcParams['xtick.minor.size'] = 5 ; mpl.rcParams['xtick.minor.width'] = 1
mpl.rcParams['ytick.major.size'] = 10 ; mpl.rcParams['ytick.major.width'] = 2;
mpl.rcParams['ytick.minor.size'] = 5 ; mpl.rcParams['ytick.minor.width'] = 1
from matplotlib.ticker import (AutoMinorLocator);
from matplotlib.lines import Line2D ; from matplotlib import cm ; import matplotlib.colors as mcolors


#%%
#open the files containing all geometries ; compute the values of geom param
data = [pd.read_json('./geometry_nobonds'+str(deprot_degree)+'.json') for deprot_degree in range(11)]
for dat in data : 
    dat['time'] = np.linspace(0,1,len(data[0]))    
    dat['max_elong'] = [np.linalg.norm(orient) for orient in dat['orientations']]
    dat['norm_asps'] = dat['asps']/dat['rgs']**2

#%%
#plot the auto-correlation of single geometrical parameter over time with confidence bands
qty='norm_asps'
def autocorr(qty):
    colors = plt.cm.get_cmap('inferno',len(data)+1) #['b','r','g','m','c'] 
    colors = ['r','g','b']
    fig,ax = plt.subplots() ; 
    color=0
    for d,dat in enumerate(data):
        #only plot a few deprotonation degrees        
        if d==0 or d==4 or d==10 :   
            serie = dat[qty] ; lags = np.arange(len(serie))
            pd.plotting.autocorrelation_plot(serie,ax=ax,c=colors[color],
                                             label='Deprot. degree = '+str(d))

######
#Multiple checks to ensure pd's function do the right calculations 
#pd seems to be the most efficient 
            #acf = [serie.autocorr(i) for i in range(len(serie))]
# =============================================================================
#             # Pre-allocate autocorrelation table
#             acorr = len(lags) * [0]
#             mean = sum(serie)/len(serie) 
#             var = sum([(x - mean)**2 for x in serie]) / len(serie) 
#             ndata = [x - mean for x in serie]
#             for l in lags:
#                 c = 1 # Self correlation
#                 if (l > 0):
#                     tmp = [ndata[l:][i] * ndata[:-l][i] 
#                            for i in range(len(serie) - l)] ;
#                     
#                     c = sum(tmp)/len(serie)/var
#                 acorr[l] = c
#
#            #import statsmodels.api as sm
#            #acorr,confint = sm.tsa.acf(serie, nlags = len(lags)-1,alpha=0.05) 
#            #acorr,confint = sm.graphics.tsa.plot_acf(serie, lags = len(lags)-1,alpha=0.05) 
#
#
#             x = np.array(serie); mean = np.mean(serie);var = np.var(serie)
#             # Normalized data
#             ndata = serie - mean            
#             acorr = np.correlate(ndata, ndata, 'full')[len(ndata)-1:] 
#             acorr = acorr/var/len(ndata)
# =============================================================================
    
    #beautifulllllllll square graphics
    ax.set_ylim(-0.45,1.0)    
    ax.set_ylabel('Autocorrelation function : Max. elong') ; 
    ax.set_xlabel('Lag (ns)')
    ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
    ax.xaxis.set_minor_locator(AutoMinorLocator());ax.locator_params(axis='x', nbins=12)
    ax.tick_params(which='minor',bottom=1,left=1,labelbottom=1,labelleft=1)
    plt.minorticks_on()
    ax.set_xticklabels(['0']+[str(x) for x in np.arange(0,11,1)])
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    plt.legend(frameon=False,bbox_to_anchor=(1.0,0.9))
    plt.grid(visible=False)
    return()

autocorr(qty) 

#%%
#plot the correlation btw two quantities 
qty1='norm_asps'; qty2='na_volumes'
def corr(qty1,qty2):
    colors = plt.cm.get_cmap('inferno',len(data)+1) #['b','r','g','m','c'] 
    fig,ax = plt.subplots() ; corr = [] ; degrees = []
    #easy in a loop
    for d,dat in enumerate(data):   
        corr.append(dat[[qty1,qty2]].corr().iloc[0,1]) ; degrees.append(d) 
    ax.plot(degrees,corr,c='b')
    
    #beautifulllllllll square graphics
    ax.set_ylim(-0.45,1.0)    
    ax.set_ylabel('Correlation : Norm. asps. vs Occ. volume by ions') ; 
    ax.set_xlabel('Deprot. Degree')
    ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
    ax.xaxis.set_minor_locator(AutoMinorLocator());ax.locator_params(axis='x', nbins=12)
    ax.tick_params(which='minor',bottom=1,left=1,labelbottom=1,labelleft=1)
    plt.minorticks_on()
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    plt.legend(frameon=False,bbox_to_anchor=(1.0,0.9))
    return()

#qty='PotEng'
#corr(qty1,qty2) ;

#%%
#compute the correlation of a quantity with ionic distances
qty='norm_asps'; 
def corr_to_nadist(qtys,deprot_degree):
    fig,ax = plt.subplots() ;
    dat = data[deprot_degree] ; na_dists = np.array([np.array(da) for da in dat['min_dists']]);nna=deprot_degree+3
    for q,qty in enumerate(qtys) :
        corr = []
        for na in range(nna) : 
            corr.append(np.corrcoef(dat[qty],na_dists[:,na])[0,1]) 
        if qty == 'norm_asps': ax.plot(np.linspace(1,nna,nna),corr,marker='o',c='b',linestyle='--',label='Norm. asphericity')
        elif qty == 'max_elong':  ax.plot(np.linspace(1,nna,nna),corr,marker='o',c='r',linestyle='-.',label='Max. elongation')
    
    #beautifulllllllll square graphics
    ax.set_ylim(-1,1.0)    
    ax.set_ylabel('Correlation with ion distance') ; 
    ax.set_xlabel('Ion number')
    ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
    ax.locator_params(axis='x', nbins=nna-1);ax.locator_params(axis='y', nbins=10)
    plt.minorticks_on()
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    plt.legend(frameon=False,bbox_to_anchor=(1.0,0.9))
    plt.title('Deprot degree = '+str(deprot_degree))
    return()

qtys=['norm_asps','max_elong'];
#call for different deprotonation degrees
for deprot_degree in [0,3,6,9]:
    corr_to_nadist(qtys,deprot_degree) ;

#%%
#compute the correlation of ionic distances wrt each other : cross-correlation
def corr_nadist(deprot_degree):
    fig,ax = plt.subplots() ; corr = [] ; 
    dat = data[deprot_degree] ; na_dists = np.array([np.array(da) for da in dat['min_dists']])
    colors = plt.cm.get_cmap('inferno') #['b','r','g','m','c'] 
    corr = np.zeros((deprot_degree+3,deprot_degree+3))
    for na1 in range(deprot_degree+3) :
        for na2 in range(deprot_degree+3) :
            corr[na1,na2]=np.corrcoef(na_dists[:,na1],na_dists[:,na2])[0,1]
    c=ax.imshow(corr,cmap='seismic',vmin=-1,vmax=1); 
    ax.set_xticklabels([str(x) for x in range(0,len(corr)+1)])
    ax.set_yticklabels([str(x) for x in range(0,len(corr)+1)])
    ax.set_ylabel('Ion number') ; 
    ax.set_xlabel('Ion number')
    ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
    ax.locator_params(axis='x', nbins=deprot_degree+3);ax.locator_params(axis='y', nbins=deprot_degree+3)
    ax.tick_params(which='minor',bottom=1,left=1,labelbottom=1,labelleft=1)
    cbar=fig.colorbar(c,ax=ax,label='Correlation') 
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    #plt.title('Deprot. degree = '+str(deprot_degree))
    return()

#call for different deprotonation degrees
for deprot_degree in [0,3,6,9] : corr_nadist(deprot_degree)
    