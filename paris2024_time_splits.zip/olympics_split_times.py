#cp athlete performances over the three last olympics
#plot the elevation, the total time and the 5km split times
import pandas as pd ; import ast ; 
import matplotlib.dates as mdates

import matplotlib.pyplot as plt ; import matplotlib as mpl ; import numpy as np
from matplotlib.lines import Line2D ; 
mpl.rcParams['xtick.major.size'] = 10 ; mpl.rcParams['xtick.major.width'] = 2;
mpl.rcParams['xtick.minor.size'] = 5 ; mpl.rcParams['xtick.minor.width'] = 1
mpl.rcParams['ytick.major.size'] = 10 ; mpl.rcParams['ytick.major.width'] = 2;
mpl.rcParams['ytick.minor.size'] = 5 ; mpl.rcParams['ytick.minor.width'] = 1
from matplotlib.font_manager import FontProperties
from matplotlib import font_manager 
font_path = './WorldAthletics.ttf'
font_manager.fontManager.addfont(font_path); font = FontProperties(fname=font_path)
plt.rcParams['font.family'] = font.get_name();plt.rcParams['font.size'] = 26

#create the axis
fig,ax=plt.subplots() ; ax_bis = fig.add_axes(ax.get_position())

#colors set up and checkpoints distances
colors = ['g','r','b']
dists = [5,10,15,20,21.1,25,30,35,40,42.2]

#initiate data for the chosen sex : 'women' or 'men'
sex='women'
for olympics in ['rio2016','tokyo2020','paris2024'] : 
    globals()[olympics] = pd.read_csv(sex+'_'+olympics+'.csv',index_col=0)
    globals()[olympics].index=['final','40k','35k','30k','25k','half','20k','15k','10k','5k','start']
    #pre-process for non-Paris data, different format
    if 'paris' not in olympics : globals()[olympics] = globals()[olympics].iloc[:,1:]

from datetime import datetime
#go to each olympics !
for o,olympics in enumerate(['rio2016','tokyo2020','paris2024']) :
    
    #pre-process uniformization for paris vs non-paris format
    if 'rio' in olympics or 'tokyo' in olympics :
        
        #gather all time splits in a list
        splits = [pd.DataFrame([ast.literal_eval(time[1]) if not pd.isna(time[1]) else ['']*4 for time in globals()[olympics].iloc[i].items()], columns=['pos','name','country','time'])\
        for i in range(1,len(globals()[olympics])-1)]
        #get rid of failed splits
        for i in range(len(splits)) : splits[i] = splits[i][splits[i]['time']!='0']
        
        #gather finish times
        results = [pd.DataFrame([ast.literal_eval(time[1]) if not pd.isna(time[1]) else [''] for time in globals()[olympics].iloc[i].items()], columns=['pos','bib','country','name','time']) for i in range(0,1)]
        #format finish time to get rid of "PB, OR,.."
        results[0]['time']=[time[:-3] if len(time)>9 else time for time in results[0]['time']]
        
        #gather splits and finish time
        splits = [results[0].drop(columns='bib')]+splits
    
    elif 'paris' in olympics :
        
        #gather all time splits in a list
        splits = [pd.DataFrame([ast.literal_eval(time[1]) if not pd.isna(time[1]) else ['']*5 for time in globals()[olympics].iloc[i].items()], columns=['pos','country','name','time','GAP'])\
        for i in range(1,len(globals()[olympics])-1)]
        
        #gather finish times    
        results = [pd.DataFrame([ast.literal_eval(time[1]) if not pd.isna(time[1]) else [''] for time in globals()[olympics].iloc[i].items()], columns=['pos','bib','country','name','time']) for i in range(0,1)]
        #format finish time to get rid of "PB, OR,.."
        results[0]['time']=[time[:-3] if len(time)>9 else time for time in results[0]['time']]
        
        #gather splits and finish time
        splits = [results[0].drop(columns='bib')]+splits
    
    #######################
    #plot finish race time
    #! blanc space in a few women times
    if sex == 'women' : splits[0]['time'] = [x[:-1] if x[-1]==' ' else x for x in splits[0]['time']] 
    #set up the right format to plot
    time_obj = [datetime.strptime(splits[i].iloc[0]['time'], "%H:%M:%S") if len(splits[i].iloc[0]['time'])>5 else datetime.strptime(splits[i].iloc[0]['time'], "%M:%S") for i in range(len(splits))][::-1]

    #for each split, we plot the race time in dots 'o'
    for s,split in enumerate(splits) : 
        ax.plot(dists[s],time_obj[s],color=colors[o],linestyle='',marker='o',markersize=12)

    #moving on to steps plot...
    #update the distances : we don't want the half split
    dists = [5,10,15,20,25,30,35,40,42.2]
    #initiate starting time to compute time differences from 0
    start = splits[-1].copy() ; start['time']=['00:00']*len(start)
    #get rid of the half split ; !!!!! data in the reverse order, from 
    #finish to start
    splits = splits[0:5]+splits[6:]+[start]
    #format the time
    time_obj = [datetime.strptime(splits[i].iloc[0]['time'], "%H:%M:%S") if len(splits[i].iloc[0]['time'])>5 else datetime.strptime(splits[i].iloc[0]['time'], "%M:%S") for i in range(len(splits))][::-1]
    #compute time differences
    time_diff = [(time_obj[i+1]-time_obj[i]).seconds/60 for i in range(len(time_obj)-1)]
    #plot every steps on the twin ax ; 
    #! adapt the bin center to the desired with (here 5km and 2.2km for the last)
    for s in range(len(time_diff)):
        if s == len(time_diff)-1 :
            ax_bis.bar(dists[s]-1.1,time_diff[s],color=colors[o],alpha=0.2,width=2.2,edgecolor='black')
        else : ax_bis.bar(dists[s]-2.5,time_diff[s],color=colors[o],alpha=0.2,width=5,edgecolor='black')

###################################
#finally, get the elevation profile
from gpxcsv import gpxtolist ; import geopy.distance
gpx_list = gpxtolist('marathon.gpx')
df = pd.DataFrame(gpx_list) ; print(df.columns)
                                               
#third ax to plot the data, ticks invisible but does not matter here
ax_elev=fig.add_axes(ax.get_position())
ax_elev.tick_params(bottom=0,top=0,left=0,right=0,labelbottom=0,labeltop=0,labelleft=0,labelright=0)

#compute the distances to plot elevation = f(distance)
dist = [geopy.distance.geodesic(tuple(df[['lat','lon']].iloc[i]),tuple(df[['lat','lon']].iloc[i+1])).m for i in range(len(df)-1)]
ax_elev.plot(np.cumsum(dist)*1e-3,df['ele'][1:],color='k') ; ax_elev.set_xlim(0,42.2)
ax_elev.set_facecolor('None');ax_elev.set_aspect(1.0/ax_elev.get_data_ratio(), adjustable='box')

#beautiful graph for sure
ax.set_xlim([0,42.2]);ax_bis.set_xlim([0,42.2]);ax_bis.set_ylim([6,20])
ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
ax_bis.set_aspect(1.0/ax_bis.get_data_ratio(), adjustable='box') ; ax.tick_params(width=2)
ax_bis.set_facecolor('None')
ax_bis.tick_params(bottom=0,top=0,left=0,right=1,labelbottom=0,labeltop=0,labelleft=0,labelright=1)
for axis in ['top','bottom','left','right']:
    ax.spines[axis].set_linewidth(2)

ax.set_ylabel('Race time (hh:mm)',labelpad=10) ; ax.set_xlabel('Distance (km)') ;ax_bis.set_ylabel('5km split (min)',rotation=270,labelpad=-600)
ax.yaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
#ax.set_yticklabels(['00:15','00:30','00:45','01:00','01:15','01:30','01:45','02:00'])
ax.legend(handles=[Line2D([0], [0], label='Rio 2016', marker='o',\
         markerfacecolor='g',markeredgecolor='g',linestyle='',markersize=12),Line2D([0], [0], label='Tokyo 2020', marker='o',\
         markerfacecolor='r',markeredgecolor='r',linestyle='',markersize=12),Line2D([0], [0], label='Paris 2024', marker='o',\
         markerfacecolor='b',markeredgecolor='b',linestyle='',markersize=12)],
         frameon=False,bbox_to_anchor=(1.18,1.12),ncols=3)
                                     
plt.show()

